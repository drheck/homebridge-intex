
<p align="center">

<img src="https://github.com/homebridge/branding/raw/master/logos/homebridge-wordmark-logo-vertical.png" width="150">

</p>


# Homebridge Intex Plugin

This is a Homebridge platform plugin for Intex Pools with WLAN.

The plugin provides the following homekit devices:
1. One Temperaturesensor (shows the current temperature, history is provided in Eve App)
2. One Thermostat accessory (Shows current temperature, you can switch heating On/Off and set the target temperature)
3. Two switches:
  3.1 Filter: Switches the Filter On/Off
  3.2 Bubbles: Switches the Bubbles On/Off


More documentation ist following...
import {
  AccessoryPlugin,
  Characteristic,
  CharacteristicGetCallback,
  CharacteristicSetCallback,
  CharacteristicValue,
  HAP,
  Logging,
  Service,
  CharacteristicEventTypes,
  PlatformConfig,
} from 'homebridge';

import { DPHIntex } from './dph_intex_Api';

const HEATER_ONOFF = 4;
const SET_PRESETTEMP = 24;


export class IntexHeater implements AccessoryPlugin {

  private readonly log: Logging;

  private switchOn = false;

  // This property must be existent!!
  name: string;

  private readonly heaterService: Service;
  private informationService: Service;
  private readonly Characteristic: typeof Characteristic;

  private heaterOn = false;
  private heaterint = 10;
  config: PlatformConfig;

  constructor(hap: HAP, log: Logging, name: string, mrSPA: DPHIntex, config: PlatformConfig) {
    this.log = log;
    this.config = config;
    this.name = name;

    this.Characteristic = hap.Characteristic;

    // create a new heater service
		this.heaterService = new hap.Service.HeaterCooler(name);
		this.heaterService.getCharacteristic(this.Characteristic.HeatingThresholdTemperature).setProps({
      minValue: 10,
      maxValue: 40,
      minStep: 1,
    });
    this.heaterService.getCharacteristic(this.Characteristic.TargetHeaterCoolerState)
      .setProps({
        maxValue: this.Characteristic.TargetHeaterCoolerState.HEAT,
      });
    this.heaterService.getCharacteristic(this.Characteristic.CurrentHeaterCoolerState)
      .setProps({
        maxValue: this.Characteristic.CurrentHeaterCoolerState.HEATING,
      });

		// create handlers for required characteristics
    this.heaterService.getCharacteristic(this.Characteristic.CurrentHeaterCoolerState)
      .on(CharacteristicEventTypes.GET, (callback: CharacteristicGetCallback) => {
        log.debug('Current CurrentHeaterCoolerState of the heater was returned: ' + (mrSPA.mHeater ? 'ON' : 'OFF'));
        callback(undefined, mrSPA.mHeater);
      });

    this.heaterService.getCharacteristic(this.Characteristic.TargetHeaterCoolerState)
      .on(CharacteristicEventTypes.GET, (callback: CharacteristicGetCallback) => {
        log.debug('Current TargetHeaterCoolerState of the heater was returned: ' + (mrSPA.mHeater ? 'ON' : 'OFF'));
        callback(undefined, mrSPA.mHeater);
      })
      .on(CharacteristicEventTypes.SET, (value: CharacteristicValue, callback: CharacteristicSetCallback) => {
        this.heaterOn = value as boolean;
        if (mrSPA._isUpdatingUI) {
          return;
        }
        log.debug('heater TargetHeaterCoolerState was set to: ' + (this.heaterOn ? 'ON' : 'OFF'));
        mrSPA.execCommand(HEATER_ONOFF, this.heaterOn);
        callback();
      });

    this.heaterService.getCharacteristic(this.Characteristic.CurrentTemperature)
      .on(CharacteristicEventTypes.GET, (callback: CharacteristicGetCallback) => {
        log.debug('Current CurrentTemperature of the heater was returned: ' + (mrSPA.mcurTemp));
        callback(undefined, mrSPA.mcurTemp);
      });

		this.heaterService.getCharacteristic(this.Characteristic.HeatingThresholdTemperature)
      .on(CharacteristicEventTypes.GET, (callback: CharacteristicGetCallback) => {
				log.debug('Current HeatingThresholdTemperature of the heater was returned: ' + (mrSPA.mpresetTemp));
        callback(undefined, mrSPA.mpresetTemp);
      })
      .on(CharacteristicEventTypes.SET, (value: CharacteristicValue, callback: CharacteristicSetCallback) => {
        this.heaterint = Number(value);
        if (mrSPA._isUpdatingUI) {
          return;
        }
				log.debug('heater HeatingThresholdTemperature was set to: ' + (this.heaterint));
        mrSPA.execCommand(SET_PRESETTEMP, this.heaterint);
        callback();
      });


    //Characteristic.TemperatureDisplayUnits.CELSIUS = 0;
    //Characteristic.TemperatureDisplayUnits.FAHRENHEIT = 1;
    this.heaterService.getCharacteristic(this.Characteristic.TemperatureDisplayUnits)
      .on(CharacteristicEventTypes.GET, (callback: CharacteristicGetCallback) => {
        log.debug('Current TemperatureDisplayUnits of the heater was returned: ' + (mrSPA.mTempUnit));	// ? "FAHRENHEIT" : "CELSIUS"));
        callback(undefined, mrSPA.mTempUnit);
      })
      .on(CharacteristicEventTypes.SET, (value: CharacteristicValue, callback: CharacteristicSetCallback) => {
        this.heaterint = Number(value);
        log.debug('heater TemperatureDisplayUnits was set to: ' + (this.heaterint ? 'FAHRENHEIT' : 'CELSIUS'));
        callback();
      });

    //this.heaterService.getCharacteristic(this.Characteristic.TemperatureDisplayUnits)
    //.setValue(this.Characteristic.TemperatureDisplayUnits.CELSIUS);
    //Characteristic.CurrentHeaterCoolerState.OFF = 0;
    //Characteristic.CurrentHeaterCoolerState.HEAT = 1;
    //Characteristic.CurrentHeaterCoolerState.COOL = 2;

		//Test
		//this.heaterService.getCharacteristic(this.Characteristic.CurrentRelativeHumidity).updateValue(13);
		//this.heaterService.getCharacteristic(this.Characteristic.TargetRelativeHumidity).updateValue(20);

    this.informationService = new hap.Service.AccessoryInformation()
      .setCharacteristic(hap.Characteristic.Manufacturer, this.config.manufacturer)
      .setCharacteristic(hap.Characteristic.Model, this.config.model)
      .setCharacteristic(hap.Characteristic.SerialNumber, 'SN_' + this.name);

		mrSPA._Heater	= this;
  }


  /**
   * Handle requests to get the current value of the "Current Heating Cooling State" characteristic
   */
  handleCurrentHeaterCoolerStateGet() {
    this.log.debug('Triggered GET CurrentHeaterCoolerState');

    // set this to a valid value for CurrentHeaterCoolerState
    const currentValue = this.Characteristic.CurrentHeaterCoolerState.INACTIVE;

    return currentValue;
  }

  /**
   * Handle requests to set the "Target Heating Cooling State" characteristic
   */
  handleCurrentHeaterCoolerStateSet(value) {
    this.log.debug('Triggered SET CurrentHeaterCoolerState:', value);
    this.heaterService.getCharacteristic(this.Characteristic.CurrentHeaterCoolerState).updateValue(value);
  }

  /**
   * Handle requests to get the current value of the "Target Heating Cooling State" characteristic
   */
  handleTargetHeaterCoolerStateGet() {
    this.log.debug('Triggered GET TargetHeaterCoolerState');

    // set this to a valid value for TargetHeaterCoolerState
    const currentValue = this.Characteristic.TargetHeaterCoolerState.AUTO;

    return currentValue;
  }

  /**
   * Handle requests to set the "Target Heating Cooling State" characteristic
   */
  handleTargetHeaterCoolerStateSet(value) {
    this.log.debug('Triggered SET TargetHeaterCoolerState:', value);
    this.heaterService.getCharacteristic(this.Characteristic.TargetHeaterCoolerState).updateValue(value);
  }

  /**
   * Handle requests to get the current value of the "Current Temperature" characteristic
   */
  handleCurrentTemperatureGet() {
    this.log.debug('Triggered GET CurrentTemperature');

    // set this to a valid value for CurrentTemperature
    const currentValue = -270;

    return currentValue;
  }

  /**
   * Handle requests to set the "Target Temperature" characteristic
   */
  handleCurrentTemperatureSet(value) {
    this.log.debug('Triggered SET CurrentTemperature:', value);
    this.heaterService.getCharacteristic(this.Characteristic.CurrentTemperature).setValue(value);
  }

  /**
   * Handle requests to get the current value of the "Target Temperature" characteristic
   */
  handleTargetTemperatureGet() {
		this.log.debug('Triggered GET HeatingThresholdTemperature');

    // set this to a valid value for TargetTemperature
    const currentValue = 10;

    return currentValue;
  }

  /**
   * Handle requests to set the "Target Temperature" characteristic
   */
  handleTargetTemperatureSet(value) {
		this.log.debug('Triggered SET HeatingThresholdTemperature:', value);
		this.heaterService.getCharacteristic(this.Characteristic.HeatingThresholdTemperature).updateValue(value);
  }

  /**
   * Handle requests to get the current value of the "Temperature Display Units" characteristic
   */
  handleTemperatureDisplayUnitsGet() {
    this.log.debug('Triggered GET TemperatureDisplayUnits');

    // set this to a valid value for TemperatureDisplayUnits
    const currentValue = this.Characteristic.TemperatureDisplayUnits.CELSIUS;

    return currentValue;
  }

  /**
   * Handle requests to set the "Temperature Display Units" characteristic
   */
  handleTemperatureDisplayUnitsSet(value) {
    this.log.debug('Triggered SET TemperatureDisplayUnits:', value);
  }

  /*
 * This method is optional to implement. It is called when HomeKit ask to identify the accessory.
 * Typical this only ever happens at the pairing process.
 */
  identify(): void {
    this.log('Identify!');
  }

  /*
   * This method is called directly after creation of this instance.
   * It should return all services which should be added to the accessory.
   */
  getServices(): Service[] {
    return [
      this.informationService,
      this.heaterService,
    ];
  }

}
